// src/pages/DeviceTrends.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { LineChart } from '@mui/x-charts/LineChart';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';

import { latestbydevice } from '../api';
import Gauge90 from '../components/Gauge90';
import Loader from '../components/Loader';
import StatusPill from '../components/StatusPill';

// ---- Metric config ----
const METRICS = [
{
key: 'pressure',
label: 'Pressure',
fieldKeys: ['pressure_psi', 'pressure'],
min: 0,
max: 150,
units: 'psi',
goodMin: 40,
goodMax: 110,
},
{
key: 'temp',
label: 'Temperature',
fieldKeys: ['temp_c', 'temperature_c', 'temperature'],
min: 0,
max: 70,
units: '°C',
goodMin: 5,
goodMax: 45,
},
{
key: 'vibration',
label: 'Vibration',
fieldKeys: ['vibration_rms', 'vibration'],
min: 0,
max: 4000,
units: 'mg RMS',
goodMin: 1000,
goodMax: 3000,
},
{
key: 'ppm',
label: 'Parts per Million',
fieldKeys: ['parts_per_million', 'ppm'],
min: 0,
max: 2000,
units: 'ppm',
goodMin: 200,
goodMax: 1200,
},
{
key: 'moisture',
label: 'Soil Moisture',
fieldKeys: ['soil_moisture_pct', 'soil_moisture'],
min: 0,
max: 100,
units: '%',
goodMin: 20,
goodMax: 60,
},
{
key: 'ph',
label: 'Soil pH',
fieldKeys: ['soil_ph', 'ph'],
min: 3,
max: 10,
units: 'pH',
goodMin: 5.8,
goodMax: 7.2,
},
{
key: 'ec',
label: 'Electrical Conductivity',
fieldKeys: ['electrical_conductivity_ms_cm', 'ec_ms_cm', 'soil_ec'],
min: 0,
max: 10,
units: 'mS/cm',
goodMin: 0.5,
goodMax: 3.0,
},
];

// These rows are always visible
const ALWAYS_ON_KEYS = ['pressure', 'temp', 'vibration'];

export default function DeviceTrendsPage() {
const { deviceId } = useParams();
const [data, setData] = useState(null);
const [err, setErr] = useState('');
const [loading, setLoading] = useState(true);

// visibility state for optional metrics
const [metricVisibility, setMetricVisibility] = useState(() => {
const vis = {};
METRICS.forEach((m) => {
if (!ALWAYS_ON_KEYS.includes(m.key)) {
vis[m.key] = true; // default ON; flip to false to start hidden
}
});
return vis;
});

useEffect(() => {
let cancelled = false;

async function load() {
if (!deviceId) return;
try {
setErr('');
setLoading(true);
const result = await latestbydevice(deviceId);
if (!cancelled) {
setData(result);
}
} catch (e) {
console.error('Failed to load device latest', e);
if (!cancelled) setErr('Failed to load device data.');
} finally {
if (!cancelled) setLoading(false);
}
}

load();
return () => {
cancelled = true;
};
}, [deviceId]);

const running = isRunning(data);
const deviceTs = data?.ts ?? data?.timestamp ?? null;
const lastSeen = timeAgo(data?.ingested_at ?? data?.ts ?? null);

const handleToggle = (key) => {
setMetricVisibility((prev) => ({
...prev,
[key]: !prev[key],
}));
};

return (
<div className="page device-trends-page">
{/* Header */}
<div className="page-header">
<div className="page-header-left">
<h1 className="page-title">
Gauge Trends –{' '}
<span className="page-title-id">
{deviceId ?? (data && data.deviceId) ?? ''}
</span>
</h1>
</div>
{data && (
<div className="page-header-right">
{/*<StatusPill ok={running} text={running ? 'Running' : 'Stopped'} />     Something is not right about this*/ }
</div>
)}
</div>

<div
className="muted"
style={{ marginTop: 4, fontSize: 12, display: 'flex', gap: 12 }}
>
<span>Device TS: {deviceTs ?? '-'}</span>
<span>Received: {lastSeen}</span>
</div>

{/* Toggles for optional metrics */}
<div
style={{
marginTop: 16,
marginBottom: 8,
display: 'flex',
flexWrap: 'wrap',
gap: 12,
alignItems: 'center',
}}
>
<span
style={{
fontSize: 12,
textTransform: 'uppercase',
letterSpacing: '0.08em',
color: 'rgba(156,163,175,1)',
}}
>
Optional Metrics:
</span>
{METRICS.filter((m) => !ALWAYS_ON_KEYS.includes(m.key)).map((metric) => (
<FormControlLabel
key={metric.key}
control={
<Switch
checked={!!metricVisibility[metric.key]}
onChange={() => handleToggle(metric.key)}
size="small"
/>
}
label={metric.label}
sx={{
'& .MuiFormControlLabel-label': {
fontSize: 12,
color: 'rgba(209,213,219,1)',
},
}}
/>
))}
</div>

{loading && !data && (
<div style={{ marginTop: 32 }}>
<Loader />
</div>
)}

{err && (
<div className="error-banner" style={{ marginTop: 12 }}>
{err}
</div>
)}

{!loading && !data && !err && (
<div className="muted" style={{ marginTop: 24 }}>
No data available for this device yet.
</div>
)}

{data && (
<div
className="kpi-trends-view"
style={{
display: 'flex',
flexDirection: 'column',
gap: 16,
marginTop: 12,
}}
>
{METRICS.filter((metric) => {
if (ALWAYS_ON_KEYS.includes(metric.key)) return true;
return !!metricVisibility[metric.key];
}).map((metric) => (
<MetricTrendRow key={metric.key} metric={metric} data={data} />
))}
</div>
)}
</div>
);
}

/* ---------------------------
* Row: Gauge on left + MUI X LineChart on right
* --------------------------- */
function MetricTrendRow({ metric, data }) {
const value = getNum(data, metric.fieldKeys);

// demo trend data around latest value
const { xLabels, yValues } = buildDemoSeries(metric, value);

return (
<div
style={{
display: 'grid',
gridTemplateColumns: '260px minmax(0, 1fr)',
gap: 16,
alignItems: 'stretch',
background: 'rgba(15,23,42,0.95)',
borderRadius: 16,
border: '1px solid rgba(31,41,55,1)',
padding: 14,
}}
>
{/* Gauge on the left */}
<div
style={{
display: 'flex',
alignItems: 'center',
justifyContent: 'center',
borderRight: '1px solid rgba(31,41,55,1)',
paddingRight: 12,
}}
>
<Gauge90
label={metric.label}
value={value}
min={metric.min}
max={metric.max}
units={metric.units}
goodMin={metric.goodMin}
goodMax={metric.goodMax}
size={180}
/>
</div>

{/* Line graph on the right */}
<div
style={{
paddingLeft: 4,
display: 'flex',
flexDirection: 'column',
gap: 6,
}}
>
<div
style={{
display: 'flex',
justifyContent: 'space-between',
alignItems: 'baseline',
marginBottom: 2,
}}
>
<div
style={{
fontSize: '0.9rem',
fontWeight: 600,
color: 'rgba(249,250,251,1)',
}}
>
{metric.label} Trend
</div>
<div
style={{
fontSize: '0.75rem',
color: 'rgba(156,163,175,1)',
}}
>
Latest:{' '}
<span style={{ color: 'rgba(209,213,219,1)' }}>
{Number.isFinite(value)
? `${value.toFixed(2)} ${metric.units}`
: '-'}
</span>
</div>
</div>

<div style={{ flex: 1, minHeight: 160 }}>
<LineChart
xAxis={[
{
scaleType: 'point',
data: xLabels,
},
]}
series={[
{
data: yValues,
},
]}
height={160}
/>
</div>
</div>
</div>
);
}

/* ---------------------------
* Helpers
* --------------------------- */
function getNum(obj, keys) {
if (!obj) return NaN;
for (const k of keys) {
if (obj[k] === null || obj[k] === undefined) continue;
const n = Number(obj[k]);
if (!Number.isNaN(n) && Number.isFinite(n)) {
return n;
}
}
return NaN;
}

function buildDemoSeries(metric, latestValue) {
const base =
Number.isFinite(latestValue) && latestValue !== 0
? latestValue
: (metric.min + metric.max) / 2;

const xLabels = ['-60m', '-45m', '-30m', '-15m', 'Now'];
const yValues = [0.92, 1.05, 0.98, 1.02, 1.0]
.map((f) => base * f)
.map((v) => clamp(v, metric.min, metric.max));

return { xLabels, yValues };
}

function clamp(x, lo, hi) {
return Math.min(hi, Math.max(lo, x));
}

function isRunning(data) {
if (!data) return false;
const candidates = [
data.pump_running,
data.running,
data.isRunning,
data.is_running,
];
for (const c of candidates) {
if (c === null || c === undefined) continue;
if (typeof c === 'boolean') return c;
if (typeof c === 'number') return c !== 0;
if (typeof c === 'string') {
const s = c.toLowerCase();
if (s === 'true' || s === 'running' || s === 'on' || s === '1') return true;
if (s === 'false' || s === 'stopped' || s === 'off' || s === '0') return false;
}
}
return false;
}

function timeAgo(ts) {
if (!ts) return '-';
let date;
if (typeof ts === 'number') {
if (ts < 1e12) {
date = new Date(ts * 1000);
} else {
date = new Date(ts);
}
} else {
const parsed = Date.parse(ts);
if (!Number.isNaN(parsed)) {
date = new Date(parsed);
} else {
return String(ts);
}
}
const now = new Date();
const diffMs = now - date;
if (diffMs < 0) return 'just now';
const sec = Math.floor(diffMs / 1000);
const min = Math.floor(sec / 60);
const hr = Math.floor(min / 60);
const day = Math.floor(hr / 24);

if (day > 0) return `${day}d ${hr % 24}h ago`;
if (hr > 0) return `${hr}h ${min % 60}m ago`;
if (min > 0) return `${min}m ago`;
return `${sec}s ago`;
}